export class Post {
    $key: string;
    title: string;
    content: string;
}
