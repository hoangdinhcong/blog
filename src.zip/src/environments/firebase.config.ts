export const firebaseConfig = {
    apiKey: 'AIzaSyCtQyL8roLpaAoKc1H66FGxJcF8YBFQ7b0',
    authDomain: 'hoangdinhcong-github-io.firebaseapp.com',
    databaseURL: 'https://hoangdinhcong-github-io.firebaseio.com',
    projectId: 'hoangdinhcong-github-io',
    storageBucket: 'hoangdinhcong-github-io.appspot.com',
    messagingSenderId: '976019831217'
};
